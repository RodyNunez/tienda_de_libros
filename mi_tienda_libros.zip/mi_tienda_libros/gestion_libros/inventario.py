
inventario = [] 


def crear_libro(titulo, autor, precio):  #estas variables del def los usaremos para el main.py, donde haremos las preguntas de insercion del nuevo libro
    libro = {'titulo': titulo, 'autor': autor, 'precio': precio, 'cantidad': 1}  #esta cadena servira para almacenar la informacion del nuevo libro, los nombres desen ser constantes he iguales aqui
    inventario.append(libro)
    print(f"el libro {titulo} se ha añadido con exito")
    print("Inventario actual:", inventario)  # Para verificar la estructura del inventario

def mostrar_inventario():  # definicion para mostrar los libros disponibles o si no hay nada
    if not inventario:
        print("El inventario está vacío.")
    else:
        print("\nInventario de libros disponibles:")
        for idx, libro in enumerate(inventario, 1):
            print(f"{idx}. {libro['titulo']} - {libro['autor']} (${libro['precio']}) - Cantidad: {libro['cantidad']}")



