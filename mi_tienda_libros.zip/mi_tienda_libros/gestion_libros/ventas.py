from gestion_libros.inventario import inventario

total_ventas = 0 

def vender_libro(titulo):
    global total_ventas
    for libro in    inventario:
        if libro ['titulo'] == titulo and libro ['cantidad'] > 0:
            libro['cantidad'] -= 1
            total_ventas += libro['precio']
            print(f"El libro '{titulo}' fue vendido por ${libro['precio']}.")
            return
    print(f"El libro '{titulo}' no está disponible en el inventario.")


def mostrar_total_ventas():
    print(f"El total de ventas es: ${total_ventas}")