from gestion_libros.inventario import crear_libro, mostrar_inventario
from gestion_libros.ventas import vender_libro, mostrar_total_ventas


#todas las opciones estan funcionales, lo unico malo es que no guarda los libros al cerrar el programa, pero la venta de libros y el total recaudado funciona correctamente

def mostrar_menu():
    while True:
        """Muestra el menú principal"""
        print("\n--- Menú de la tienda de libros ---")
        print("1. Agregar libro al inventario")
        print("2. Mostrar inventario")
        print("3. Vender libro")
        print("4. Mostrar total de ventas")
        print("5. Salir")
        seleccion = input("Seleccione la accion deseada: ")   #hacemos una variable que contendra la pregunta de seleccion de accion

        if seleccion == "1":  #no olvidar que debemos poner el numero con "" para que lo acepte, si no lo hacemos pensara que estamos poniendo algo nada que ver
            titulo = input("Ingresa el titulo del libro: ")
            autor = input("Ingrese el autor del nuevo libro: ")
            precio = int(input("especifique el precio que tendra el libro a añadir: "))
            crear_libro(titulo, autor, precio)
        elif seleccion == "2":
            mostrar_inventario()
        elif seleccion == "3":
            titulo = input("Título del libro a vender: ")
            vender_libro(titulo)
        elif seleccion == "4":
            mostrar_total_ventas()
        elif seleccion == "5":
            print("fin del programa")
            break
        else:
            print("Esa opcion no es una accion valida")
        










mostrar_menu()

